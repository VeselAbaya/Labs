//2

#pragma once 
#include <stdlib.h>

int sum_between_negative(int const a[], int size);
