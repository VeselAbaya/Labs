//1
#pragma once

int index_last_negative(int const a[], int size);
