//0
#pragma once

int index_first_negative(int const a[], int size);
