//3

#pragma once 
#include <stdlib.h>

int sum_before_and_after_negative(int const a[], int size);

