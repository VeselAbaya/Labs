#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
using namespace std;

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent),
                                          ui(new Ui::MainWindow) {
    ui->setupUi(this);
    graph = new GraphWidget;
    setCentralWidget(graph);

    connect(this, SIGNAL(file_opened(QString)), graph, SLOT(file_opened(QString)));
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_actionAbout_triggered() {
    About about;
    about.exec();
}

void MainWindow::on_actionOpen_2_triggered() {
    QString input_file = QFileDialog::getOpenFileName(this, "Choose input file");
    emit file_opened(input_file);
}

void MainWindow::on_actionEnter_triggered() {

}
